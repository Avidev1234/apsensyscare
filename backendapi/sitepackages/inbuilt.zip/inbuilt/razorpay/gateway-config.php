<?php
//set your razorpay account keyid and keysecret , 
//get from razorpay account in settings 
$keyId='rzp_test_dt0Vsxsmad0Ry3'; 
$keySecret='9AdIvMqNRWm8jObYrMh2JnYy';
?>